package view;

public class CadastroFuncionarioView {
    
}
